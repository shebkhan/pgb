var krms_config ={				
	'ApiUrl':"https://www.ristasa.it/app/mobileappv2/api",	
	'AppTitle':"Ristasa",
	'ApiKey' : '3e94850d9fa43421a29db75f2fc84173',	
	'debug': false
};